package app.DTodd.gatorblocks;

public class BeginYear {
    public static int BeginYear=2019;
}

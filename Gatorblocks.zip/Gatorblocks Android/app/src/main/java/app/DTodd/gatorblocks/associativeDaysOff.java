package app.DTodd.gatorblocks;

public class associativeDaysOff {
    public static String[] associativeDaysOff= {"School Improvement Day","Thanksgiving","PRO-D day","School closed","Remembrance Day","Report Card Prep","Winter Break","Winter Break", "Winter Break","Winter Break","Winter Break","Winter Break","Winter Break","Winter Break","Winter Break","Winter Break","PRO-D day","Family Day","Report Card Prep","Spring Break","Spring Break","Spring Break","Spring Break","Spring Break","Spring Break","Spring Break","Spring Break","Spring Break","Spring Break","Good Friday","Easter Monday","Victoria Day"};
}

package app.DTodd.gatorblocks;

public class Final {
    public static int Final =180;//Enter the last day of school in day of year format
}

package app.DTodd.gatorblocks;

public class Begin {
    public static int begin =247;//Enter the first day of school in day of year format
}

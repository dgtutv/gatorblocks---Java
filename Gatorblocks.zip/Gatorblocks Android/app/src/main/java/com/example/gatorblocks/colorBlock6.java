package com.example.gatorblocks;

import android.os.Bundle;
import android.support.wearable.activity.WearableActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class colorBlock6 extends WearableActivity {

    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_block6);
        configureBlock1();
        configureBlock2();
        configureBlock3();
        configureBlock4();
        configureBlock5();
        configureBlock6();
        configureBlock7();
        configureBlock8();
        configureBlock9();


    }
    private void configureBlock1() {
        Button red = (Button) findViewById(R.id.red);
        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[5]="#7EFF0000";
                finish();
            }
        });

    }
    private void configureBlock2() {
        Button orange = (Button) findViewById(R.id.orange);
        orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[5]="#ABFF8000";
                finish();
            }
        });

    }
    private void configureBlock3() {
        Button yellow = (Button) findViewById(R.id.yellow);
        yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[5]="#8EFFFF00";
                finish();
            }
        });
    }
    private void configureBlock4() {
        Button blue = (Button) findViewById(R.id.blue);
        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[5]="#7E0026E6";
                finish();
            }
        });
    }
    private void configureBlock5() {
        Button purple = (Button) findViewById(R.id.purple);
        purple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[5]="#7EBF00E6";
                finish();
            }
        });
    }
    private void configureBlock6() {
        Button pink = (Button) findViewById(R.id.pink);
        pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[5]="#7EFF19B3";
                finish();
            }
        });
    }
    private void configureBlock7() {
        Button green = (Button) findViewById(R.id.green);
        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[5]="#7E00FF00";
                finish();
            }
        });
    }
    private void configureBlock8() {
        Button lightBlue = (Button) findViewById(R.id.lightBlue);
        lightBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[5]="#7E00FFFF";
                finish();
            }
        });
    }
    private void configureBlock9() {
        Button darkGreen = (Button) findViewById(R.id.darkGreen);
        darkGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[5]="#7E00C853";
                finish();
            }
        });
    }
}

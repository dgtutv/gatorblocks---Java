package com.example.gatorblocks;

public class ColorAccess {
    public static String[] colors={"#00FFFFFF", "#00FFFFFF", "#00FFFFFF", "#00FFFFFF", "#00FFFFFF", "#00FFFFFF", "#00FFFFFF", "#00FFFFFF"};
}

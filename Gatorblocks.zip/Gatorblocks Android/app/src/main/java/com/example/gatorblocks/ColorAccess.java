package com.example.gatorblocks;

public class ColorAccess {
    public static String[] colors={"#7EFF0000", "#ABFF8000", "#8EFFFF00", "#7E0026E6", "#7EBF00E6", "#7EFF19B3", "#7E00FF00", "#7E00FFFF", "#7E00C853"};
}

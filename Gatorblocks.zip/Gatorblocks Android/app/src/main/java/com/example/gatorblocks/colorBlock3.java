package com.example.gatorblocks;

import android.os.Bundle;
import android.support.wearable.activity.WearableActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class colorBlock3 extends WearableActivity {

    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_block3);
        configureBlock1();
        configureBlock2();
        configureBlock3();
        configureBlock4();
        configureBlock5();
        configureBlock6();
        configureBlock7();
        configureBlock8();
        configureBlock9();
        configureBlock10();
        configureBlock11();
        configureBlock12();
        configureBlock13();
        configureBlock14();
        configureBlock15();
        configureBlock16();
        configureBlock17();
        configureBlock18();

    }
    private void configureBlock1() {
        Button red = (Button) findViewById(R.id.red);
        red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7EFF0000";
                finish();
            }
        });

    }
    private void configureBlock2() {
        Button orange = (Button) findViewById(R.id.orange);
        orange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#ABFF8000";
                finish();
            }
        });

    }
    private void configureBlock3() {
        Button yellow = (Button) findViewById(R.id.yellow);
        yellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#8EFFFF00";
                finish();
            }
        });
    }
    private void configureBlock4() {
        Button blue = (Button) findViewById(R.id.blue);
        blue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7E0026E6";
                finish();
            }
        });
    }
    private void configureBlock5() {
        Button purple = (Button) findViewById(R.id.purple);
        purple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7EBF00E6";
                finish();
            }
        });
    }
    private void configureBlock6() {
        Button pink = (Button) findViewById(R.id.pink);
        pink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7EFF19B3";
                finish();
            }
        });
    }
    private void configureBlock7() {
        Button green = (Button) findViewById(R.id.green);
        green.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7E00FF00";
                finish();
            }
        });
    }
    private void configureBlock8() {
        Button lightBlue = (Button) findViewById(R.id.lightBlue);
        lightBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7E00FFFF";
                finish();
            }
        });
    }
    private void configureBlock9() {
        Button darkGreen = (Button) findViewById(R.id.darkGreen);
        darkGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7E00C853";
                finish();
            }
        });
    }
    private void configureBlock10() {
        Button alabamaCrimson = (Button) findViewById(R.id.alabamaCrimson);
        alabamaCrimson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7EAF002A";
                finish();
            }
        });

    }
    private void configureBlock11() {
        Button mahogany = (Button) findViewById(R.id.Mahogany);
        mahogany.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7EB33B00";
                finish();
            }
        });

    }
    private void configureBlock12() {
        Button airForceBlue = (Button) findViewById(R.id.airForceBlue);
        airForceBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7E00308F";
                finish();
            }
        });
    }
    private void configureBlock13() {
        Button deepCarmine = (Button) findViewById(R.id.deepCarmine);
        deepCarmine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7EAB274F";
                finish();
            }
        });
    }
    private void configureBlock14() {
        Button alienArmpit = (Button) findViewById(R.id.alienArmpit);
        alienArmpit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7E84DE02";
                finish();
            }
        });
    }
    private void configureBlock15() {
        Button gold = (Button) findViewById(R.id.gold);
        gold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7EFFD700";
                finish();
            }
        });
    }
    private void configureBlock16() {
        Button grey = (Button) findViewById(R.id.grey);
        grey.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7EB2BEB5";
                finish();
            }
        });
    }
    private void configureBlock17() {
        Button pastelMagenta = (Button) findViewById(R.id.pastelMagenta);
        pastelMagenta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#7EF19CBB";
                finish();
            }
        });
    }
    private void configureBlock18() {
        Button none = (Button) findViewById(R.id.none);
        none.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] colors = ColorAccess.colors;
                colors[2]="#00FFFFFF";
                finish();
            }
        });
    }
}

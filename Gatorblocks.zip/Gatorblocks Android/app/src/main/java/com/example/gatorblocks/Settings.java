package com.example.gatorblocks;

import android.content.Context;
import android.content.SharedPreferences;

public class Settings {
    private static final String enteredText = "text";
    SharedPreferences sPref;
    SharedPreferences.Editor editor;
    private Context context;

    public Settings(Context context) {
        this.context = context;
        sPref = context.getSharedPreferences("classes.txt", Context.MODE_PRIVATE);
        editor = sPref.edit();
    }
    public void setText(String text) {
        editor.putString(enteredText, text);
        editor.commit();
    }
    public String getText() {
        return sPref.getString(enteredText, null);
}}

package com.example.gatorblocks;

public class FirstDay {
    public static String FirstDay="Wednesday"; //Enter the weekday that the first day of school lands on
}

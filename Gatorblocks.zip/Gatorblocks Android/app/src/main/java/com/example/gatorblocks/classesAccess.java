package com.example.gatorblocks;
public class classesAccess {
    public static String[] classes = {"1-1", "1-2", "1-3", "1-4", "2-1", "2-2", "2-3", "2-4"};  //enter the classes that are associated with each block
}


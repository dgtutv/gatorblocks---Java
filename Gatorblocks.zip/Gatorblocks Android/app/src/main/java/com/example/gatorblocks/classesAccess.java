package com.example.gatorblocks;

public class classesAccess {
    public static String[] classes = {"AP comp sci", "Math", "Chemistry", "Spare", "Spare", "Physics", "Programming", "English"};  //enter the classes that are associated with each block

}

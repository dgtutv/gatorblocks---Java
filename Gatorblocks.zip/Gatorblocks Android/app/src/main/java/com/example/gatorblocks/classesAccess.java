package com.example.gatorblocks;
import android.content.Context;
import java.util.ArrayList;
import java.util.List;
import android.R.color;
public class classesAccess {
    public static String[] classes = {"1-1", "1-2", "1-3", "1-4", "2-1", "2-2", "2-3", "2-4"};  //enter the classes that are associated with each block
}

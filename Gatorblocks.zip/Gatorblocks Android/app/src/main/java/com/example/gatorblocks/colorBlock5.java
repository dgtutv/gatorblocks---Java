package com.example.gatorblocks;

import android.os.Bundle;
import android.support.wearable.activity.WearableActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class colorBlock5 extends WearableActivity {

    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_color_block5);
        configureBlock1();
        configureBlock2();
        configureBlock3();
        configureBlock4();
        configureBlock5();
        configureBlock6();
        configureBlock7();
        configureBlock8();
        configureBlock9();

        // Enables Always-on
        setAmbientEnabled();
    }
    private void configureBlock1() {
        Button red = (Button) findViewById(R.id.red);
        String[] colors = ColorAccess.colors;
        colors[4]="#7EFF0000";
        red.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                finish();
            }
        });
    }
    private void configureBlock2() {
        Button orange = (Button) findViewById(R.id.orange);
        String[] colors = ColorAccess.colors;
        colors[4]="ABFF8000";
        orange.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                finish();
            }
        });
    }
    private void configureBlock3() {
        Button yellow = (Button) findViewById(R.id.yellow);
        String[] colors = ColorAccess.colors;
        colors[4]="8EFFFF00";
        yellow.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                finish();
            }
        });
    }
    private void configureBlock4() {
        Button blue = (Button) findViewById(R.id.blue);
        String[] colors = ColorAccess.colors;
        colors[4]="7E0026E6";
        blue.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                finish();
            }
        });
    }
    private void configureBlock5() {
        Button purple = (Button) findViewById(R.id.purple);
        String[] colors = ColorAccess.colors;
        colors[0]="7EBF00E6";
        purple.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                finish();
            }
        });
    }
    private void configureBlock6() {
        Button pink = (Button) findViewById(R.id.pink);
        String[] colors = ColorAccess.colors;
        colors[4]="7EFF19B3";
        pink.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                finish();
            }
        });
    }
    private void configureBlock7() {
        Button green = (Button) findViewById(R.id.green);
        String[] colors = ColorAccess.colors;
        colors[4]="7E00FF00";
        green.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                finish();
            }
        });
    }
    private void configureBlock8() {
        Button lightBlue = (Button) findViewById(R.id.lightBlue);
        String[] colors = ColorAccess.colors;
        colors[4]="7E00FFFF";
        lightBlue.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                finish();
            }
        });
    }
    private void configureBlock9() {
        Button darkGreen = (Button) findViewById(R.id.darkGreen);
        String[] colors = ColorAccess.colors;
        colors[4]="7E00C853";
        darkGreen.setOnClickListener(new View.OnClickListener() {
            @Override

            public void onClick(View view) {
                finish();
            }
        });
    }
}

package com.example.gatorblocks;

public class swipe {
        public static int swipe;

}
